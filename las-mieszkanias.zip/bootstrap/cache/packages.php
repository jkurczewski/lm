<?php return array (
  'alexpechkarev/google-maps' => 
  array (
    'providers' => 
    array (
      0 => 'GoogleMaps\\ServiceProvider\\GoogleMapsServiceProvider',
    ),
    'aliases' => 
    array (
      'GoogleMaps' => 'GoogleMaps\\Facade\\GoogleMapsFacade',
    ),
  ),
  'andcarpi/laravel-popper' => 
  array (
    'providers' => 
    array (
      0 => 'andcarpi\\Popper\\PopperServiceProvider',
    ),
    'aliases' => 
    array (
      'Popper' => 'andcarpi\\Popper\\Facades\\Popper',
    ),
  ),
  'andreiio/blade-remix-icon' => 
  array (
    'providers' => 
    array (
      0 => 'AndreiIonita\\BladeRemixIcon\\BladeRemixIconServiceProvider',
    ),
  ),
  'blade-ui-kit/blade-icons' => 
  array (
    'providers' => 
    array (
      0 => 'BladeUI\\Icons\\BladeIconsServiceProvider',
    ),
  ),
  'codeat3/blade-clarity-icons' => 
  array (
    'providers' => 
    array (
      0 => 'Codeat3\\BladeClarityIcons\\BladeClarityIconsServiceProvider',
    ),
  ),
  'codeat3/blade-codicons' => 
  array (
    'providers' => 
    array (
      0 => 'Codeat3\\BladeCodicons\\BladeCodiconsServiceProvider',
    ),
  ),
  'codeat3/blade-fluentui-system-icons' => 
  array (
    'providers' => 
    array (
      0 => 'Codeat3\\BladeFluentUiSystemIcons\\BladeFluentUiSystemIconsServiceProvider',
    ),
  ),
  'codeat3/blade-phosphor-icons' => 
  array (
    'providers' => 
    array (
      0 => 'Codeat3\\BladePhosphorIcons\\BladePhosphorIconsServiceProvider',
    ),
  ),
  'codeat3/blade-radix-icons' => 
  array (
    'providers' => 
    array (
      0 => 'Codeat3\\BladeRadixIcons\\BladeRadixIconsServiceProvider',
    ),
  ),
  'facade/ignition' => 
  array (
    'providers' => 
    array (
      0 => 'Facade\\Ignition\\IgnitionServiceProvider',
    ),
    'aliases' => 
    array (
      'Flare' => 'Facade\\Ignition\\Facades\\Flare',
    ),
  ),
  'fideloper/proxy' => 
  array (
    'providers' => 
    array (
      0 => 'Fideloper\\Proxy\\TrustedProxyServiceProvider',
    ),
  ),
  'fruitcake/laravel-cors' => 
  array (
    'providers' => 
    array (
      0 => 'Fruitcake\\Cors\\CorsServiceProvider',
    ),
  ),
  'kolirt/laravel-openstreetmap' => 
  array (
    'providers' => 
    array (
      0 => 'Kolirt\\Openstreetmap\\ServiceProvider',
    ),
    'aliases' => 
    array (
      'Openstreetmap' => 'Kolirt\\Openstreetmap\\Facade\\Openstreetmap',
    ),
  ),
  'laravel/sail' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Sail\\SailServiceProvider',
    ),
  ),
  'laravel/tinker' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Tinker\\TinkerServiceProvider',
    ),
  ),
  'laravel/ui' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Ui\\UiServiceProvider',
    ),
  ),
  'mallardduck/blade-boxicons' => 
  array (
    'providers' => 
    array (
      0 => 'MallardDuck\\BladeBoxicons\\BladeBoxiconsServiceProvider',
    ),
  ),
  'nesbot/carbon' => 
  array (
    'providers' => 
    array (
      0 => 'Carbon\\Laravel\\ServiceProvider',
    ),
  ),
  'nunomaduro/collision' => 
  array (
    'providers' => 
    array (
      0 => 'NunoMaduro\\Collision\\Adapters\\Laravel\\CollisionServiceProvider',
    ),
  ),
  'spatie/geocoder' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\Geocoder\\GeocoderServiceProvider',
    ),
    'aliases' => 
    array (
      'Geocoder' => 'Spatie\\Geocoder\\Facades\\Geocoder',
    ),
  ),
);