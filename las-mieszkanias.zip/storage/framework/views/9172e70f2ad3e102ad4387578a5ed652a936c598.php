

<?php $__env->startSection('content'); ?>
    <div class="container-fluid d-flex justify-content-center ">
        <div class="col-12 col-lg-10 col-lg-7 col-xl-7 mb-4">
            <h2 class="card-title text-dark fs-4 header mb-2 mt-4"><b>Filtry</b></h2>
            <form action="<?php echo e(url('/')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-12 col-lg-4">
                        <label for="cities" class="form-label mb-0 mt-2 mb-md-1">Miejscowość</label>
                        <input name="localization" class="form-control <?php $__errorArgs = ['localization'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                               list="datalistOptions" value="<?php echo e(old('localization')); ?>Poznań" id="exampleDataList">
                        <datalist id="datalistOptions">
                            <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($city['slug']); ?>">
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </datalist>

                        <?php $__errorArgs = ['localization'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                        </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-12 col-lg-5">
                        <label for="cities" class="form-label mb-0 mt-2 mb-md-1">Lokalizacja miejsca docelowego <span
                                     data-tippy="Podaj lokalizację miejsca w którym najczęściej bywasz lub zależy Ci na
                                    dobrej komunikacji, np. szkoła, praca, dworzec kolejowy"><?php if (isset($component)) { $__componentOriginalcd9972c8156dfa6e5fd36675ca7bf5f21b506e2e = $component; } ?>
<?php $component = $__env->getContainer()->make(BladeUI\Icons\Components\Svg::class, []); ?>
<?php $component->withName('codicon-info'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'icon-info']); ?>
<?php if (isset($__componentOriginalcd9972c8156dfa6e5fd36675ca7bf5f21b506e2e)): ?>
<?php $component = $__componentOriginalcd9972c8156dfa6e5fd36675ca7bf5f21b506e2e; ?>
<?php unset($__componentOriginalcd9972c8156dfa6e5fd36675ca7bf5f21b506e2e); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?></span></label>
                        <input name="direction" class="form-control <?php $__errorArgs = ['direction'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                               list="datalistOptions" value="<?php echo e(old('direction')); ?>ul. Dąbrowskiego 5, Poznań"
                               id="exampleDataList">
                        <datalist id="datalistOptions">
                            <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($city['slug']); ?>">
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </datalist>

                        <?php $__errorArgs = ['direction'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                        </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-12 col-lg-3">
                        <label for="cities" class="form-label mb-0 mt-2 mb-md-1">Max. czas podróży <span  data-tippy="Podaj w
                                                                                                         minutach
                                                                                                         maksymalny czas
                                                                                                         dojazdu do
                                                                                                         lokalizacji
                                                                                                         docelowej"><?php if (isset($component)) { $__componentOriginalcd9972c8156dfa6e5fd36675ca7bf5f21b506e2e = $component; } ?>
<?php $component = $__env->getContainer()->make(BladeUI\Icons\Components\Svg::class, []); ?>
<?php $component->withName('codicon-info'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'icon-info']); ?>
<?php if (isset($__componentOriginalcd9972c8156dfa6e5fd36675ca7bf5f21b506e2e)): ?>
<?php $component = $__componentOriginalcd9972c8156dfa6e5fd36675ca7bf5f21b506e2e; ?>
<?php unset($__componentOriginalcd9972c8156dfa6e5fd36675ca7bf5f21b506e2e); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?></span></label>
                        <div class="input-group">
                            <input name="direction_time" type="number"
                                   class="form-control <?php $__errorArgs = ['direction_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                   value="<?php echo e(old('direction_time')); ?>35">
                            <span class="input-group-text" id="basic-addon2">min</span>

                            <?php $__errorArgs = ['direction_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
                <div class="row mt-md-3">
                    <div class="col-12 col-lg-5">
                        <label for="cities" class="form-label mb-0 mt-2 mb-md-1">Miesięczna wysokość czynszu</label>
                        <div class="input-group">
                            <input name="min_budget" type="number" min="100" step="1"
                                   value="<?php echo e(old('min_budget')); ?>1200" aria-label="First name"
                                   class="form-control <?php $__errorArgs = ['min_budget'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <span class="input-group-text">zł</span>
                            <span class="filter-price mx-3">-</span>
                            <input name="max_budget" type="number" min="100" step="1"
                                   value="<?php echo e(old('max_budget')); ?>1300" aria-label="First name"
                                   class="form-control <?php $__errorArgs = ['max_budget'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <span class="input-group-text ">zł</span>
                            <?php $__errorArgs = ['min_budget'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            <?php $__errorArgs = ['max_budget'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                    </div>
                    <div class="col-12 col-lg-5">
                        <label for="cities" class="form-label mb-0 mt-2 mb-md-1">Powierzchnia mieszkania</label>
                        <div class="input-group">
                            <input name="min_space" type="number" min="15" step="1" value="<?php echo e(old('min_space')); ?>50"
                                   aria-label="First name"
                                   class="form-control <?php $__errorArgs = ['min_space'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <span class="input-group-text">m2</span>
                            <span class="filter-price mx-3">-</span>
                            <input name="max_space" type="number" min="16" step="1" value="<?php echo e(old('max_space')); ?>60"
                                   aria-label="First name"
                                   class="form-control <?php $__errorArgs = ['max_space'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <span class="input-group-text ">m2</span>
                            <?php $__errorArgs = ['min_space'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <?php $__errorArgs = ['max_space'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>
                    </div>
                    <div class="col-12 col-lg-2">
                        <label for="cities" class="form-label mb-0 mt-2 mb-md-1">Liczba pokoi</label>
                        <div class="input-group">
                            <span class="input-group-text">Min</span>
                            <input name="rooms" type="number" min="1" step="1" value="<?php echo e(old('rooms')); ?>2"
                                   aria-label="First name"
                                   class="form-control <?php $__errorArgs = ['max_space'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

                            <?php $__errorArgs = ['max_space'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>

                <div class="row mt-4 d-flex align-items-center justify-content-end">
                    <div class="col-6 col-lg-3">
                        <button type="button"
                                class="btn btn-custom-outline <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border border-danger border-2 text-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                data-bs-toggle="modal" data-bs-target="#filterModal" data-bs-toggle="tooltip"
                                data-bs-placement="top" title="Tooltip on top">Zapisz filtr
                        </button>
                    </div>
                    <div class="col-6 col-lg-3">
                        <button type="submit" class="btn btn-custom-solid" name="action" data-bs-toggle="modal"
                                value="szukaj" data-bs-target="#waitingModal">Szukaj
                        </button>
                    </div>
                </div>

                <div class="modal fade" id="filterModal" data-bs-backdrop="static" tabindex="-1"
                     aria-labelledby="filterModalLabel" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="filterModalLabel">Zapisz filtr</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                        aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <label for="desc" class="form-label mb-0 mt-2 mb-md-1">Nazwa filtru (max. 32
                                    znaki)</label>
                                <input type="text" aria-label="desc" name="name" value="<?php echo e(old('name')); ?>"
                                       class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                       placeholder="Ekonomiczna lista - Poznań">

                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="modal-footer">
                                <div class="row">
                                    <div class="col">
                                        <button type="button" class="btn btn-custom-solid bg-danger"
                                                data-bs-dismiss="modal">Anuluj
                                        </button>
                                    </div>
                                    <div class="col mb-2">
                                        <button type="submit" name="action" class="btn btn-custom-solid" value="zapisz">
                                            Zapisz
                                        </button>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>

            </form>
            <div class="modal fade" id="waitingModal" data-bs-backdrop="static" tabindex="-1"
                 aria-labelledby="waitingModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content">
                        <div class="modal-body mt-4 mb-4">
                            
                            <div class="d-flex justify-content-center align-items-center flex-column">
                                <span id="flats" class="display-4"><b>0</b></span>
                                <span class="">Znalezionych mieszkań dla Ciebie!</span>
                                <span class="small text-secondary">Zrelaksuj się, proces poszukowania może potrwać kilka minut.</span>
                            </div>
                        </div>
                        <div class="slider">
                            <div class="line"></div>
                            <div class="subline inc"></div>
                            <div class="subline dec"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <hr class="m-0"/>

    <div class="container-fluid d-flex justify-content-center bg-search pt-5">
        <div class="col-12 col-lg-10 col-lg-7 col-xl-7">
            <h2 class="card-title text-dark fs-4 header mb-4">Znalezionych mieszkań dla Ciebie: <b><?php echo e($flats); ?></b></h2>
            <div class="row row-cols-1 row-cols-md-3 g-4">
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $flat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-12 col-md-6 col-xl-4 mb-4">
                        <div class="card h-100">
                            <ul class="nav nav-pills" id="pills-tab" role="tablist">
                                <li class="nav-item" role="presentation">
                                    <button class="btn btn-custom-outline active"
                                            id="pills-home-tab-<?php echo e($flat['rand']); ?>" data-bs-toggle="pill"
                                            data-bs-target="#pills-home-<?php echo e($flat['rand']); ?>" type="button" role="tab"
                                            aria-controls="pills-home-<?php echo e($flat['rand']); ?>" aria-selected="true">Zdjęcie
                                    </button>
                                </li>
                                <li class="nav-item" role="presentation">
                                    <button class="btn btn-custom-outline border-button"
                                            id="pills-profile-tab-<?php echo e($flat['rand']); ?>" data-bs-toggle="pill"
                                            data-bs-target="#pills-profile-<?php echo e($flat['rand']); ?>" type="button" role="tab"
                                            aria-controls="pills-profile-<?php echo e($flat['rand']); ?>" aria-selected="false">Mapa
                                    </button>
                                </li>
                            </ul>

                            <div class="tab-content" id="pills-tabContent">
                                <div class="tab-pane fade show active" id="pills-home-<?php echo e($flat['rand']); ?>"
                                     role="tabpanel" aria-labelledby="pills-home-tab-<?php echo e($flat['rand']); ?>">
                                    <img src="<?php echo e($flat['photo']); ?>" class="search-img" alt="">
                                </div>
                                <div class="tab-pane fade" id="pills-profile-<?php echo e($flat['rand']); ?>" role="tabpanel"
                                     aria-labelledby="pills-profile-tab-<?php echo e($flat['rand']); ?>">

                                    <iframe class="card-img-top" width="100%" height="350"
                                            src="https://maps.google.com/maps?q=<?php echo e($flat['localization']); ?>&output=embed&z=12"></iframe>
                                </div>
                            </div>
                            <div class="card-body pb-0 pt-1">
                                <h5 class="col-12 mt-2 card-title fs-6"><?php echo e($flat['localization']); ?></h5>
                                <h5 class="col-12 mt-2 mb-3 card-title fs-5 fw-bold price"><b><?php echo e($flat['price']); ?></b>
                                </h5>
                            </div>

                            <div class="row px-4">
                                <hr class="mb-2"/>
                                <div class="col px-0 details-wrapper d-flex justify-content-center">
                                    <div class="icon-details me-2">
                                        <?php if (isset($component)) { $__componentOriginalcd9972c8156dfa6e5fd36675ca7bf5f21b506e2e = $component; } ?>
<?php $component = $__env->getContainer()->make(BladeUI\Icons\Components\Svg::class, []); ?>
<?php $component->withName('phosphor-house'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalcd9972c8156dfa6e5fd36675ca7bf5f21b506e2e)): ?>
<?php $component = $__componentOriginalcd9972c8156dfa6e5fd36675ca7bf5f21b506e2e; ?>
<?php unset($__componentOriginalcd9972c8156dfa6e5fd36675ca7bf5f21b506e2e); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                                    </div>
                                    <div class="mt-2 icon-text">
                                        Metraż<br><b class="fs-6"><?php echo e($flat['space']); ?> </b>
                                    </div>
                                </div>
                                <div class="col ps-0 pe-2 details-wrapper d-flex justify-content-center">
                                    <div class="icon-details me-2">
                                        <?php if (isset($component)) { $__componentOriginalcd9972c8156dfa6e5fd36675ca7bf5f21b506e2e = $component; } ?>
<?php $component = $__env->getContainer()->make(BladeUI\Icons\Components\Svg::class, []); ?>
<?php $component->withName('bx-time-five'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalcd9972c8156dfa6e5fd36675ca7bf5f21b506e2e)): ?>
<?php $component = $__componentOriginalcd9972c8156dfa6e5fd36675ca7bf5f21b506e2e; ?>
<?php unset($__componentOriginalcd9972c8156dfa6e5fd36675ca7bf5f21b506e2e); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                                    </div>
                                    <div class="mt-2 icon-text">
                                        Dojazd<br><b class="fs-6"><?php echo e($flat['dir_time']); ?> min</b>
                                    </div>
                                </div>
                                <div class="col px-0 details-wrapper d-flex justify-content-center">
                                    <div class="icon-details me-2">
                                        <?php if (isset($component)) { $__componentOriginalcd9972c8156dfa6e5fd36675ca7bf5f21b506e2e = $component; } ?>
<?php $component = $__env->getContainer()->make(BladeUI\Icons\Components\Svg::class, []); ?>
<?php $component->withName('fluentui-conference-room-28'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalcd9972c8156dfa6e5fd36675ca7bf5f21b506e2e)): ?>
<?php $component = $__componentOriginalcd9972c8156dfa6e5fd36675ca7bf5f21b506e2e; ?>
<?php unset($__componentOriginalcd9972c8156dfa6e5fd36675ca7bf5f21b506e2e); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                                    </div>
                                    <div class="mt-2 icon-text">
                                        Pokoje<br><b class="fs-6"><?php echo e($flat['rooms']); ?></b>
                                    </div>
                                </div>
                            </div>

                            <div class="row m-0 p-0">
                                <a href="<?php echo e($flat['url']); ?>" target="_blank"
                                   class="mt-4 btn btn-custom-solid btn-cards">Otwórz w nowej karcie</a>
                                <div class="btn-heart_active--wrapper">
                                    <form id="StoreFav-<?php echo e($flat['rand']); ?>">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" value="<?php echo e($flat['localization']); ?>" name="localization">
                                        <input type="hidden" value="<?php echo e($flat['price']); ?>" name="price">
                                        <input type="hidden" value="<?php echo e($flat['space']); ?>" name="space">
                                        <input type="hidden" value="<?php echo e($flat['rooms']); ?>" name="rooms">
                                        <input type="hidden" value="<?php echo e($flat['dir_time']); ?>" name="time">
                                        <input type="hidden" value=<?php echo e($flat['photo']); ?> name="photo">
                                        <input type="hidden" value="<?php echo e($flat['url']); ?>" name="url">
                                        <button id="<?php echo e($flat['rand']); ?>" class="mt-4 btn btn-heart_add">
                                            <?php if (isset($component)) { $__componentOriginalcd9972c8156dfa6e5fd36675ca7bf5f21b506e2e = $component; } ?>
<?php $component = $__env->getContainer()->make(BladeUI\Icons\Components\Svg::class, []); ?>
<?php $component->withName('clarity-heart-solid'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalcd9972c8156dfa6e5fd36675ca7bf5f21b506e2e)): ?>
<?php $component = $__componentOriginalcd9972c8156dfa6e5fd36675ca7bf5f21b506e2e; ?>
<?php unset($__componentOriginalcd9972c8156dfa6e5fd36675ca7bf5f21b506e2e); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                                        </button>
                                    </form>
                                    <script>
                                        window.favs_store = "<?php echo e(route('favs.store')); ?>";
                                    </script>
                                </div>
                            </div>
                            <script>

                            </script>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\lm\las-mieszkanias\resources\views/search/search.blade.php ENDPATH**/ ?>