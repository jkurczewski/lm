



<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row d-flex justify-content-center align-items-center">
        <div class="d-none d-md-flex col-md align-items-end bg-cover bg-login">
            <h2 class="text-white pb-3 ps-3"><b>Cagliari</b><br>Miasto na Sardynii, Włochy</h2>
        </div>
            <div class="col-sm-12 col-md-6">
                <div class="row d-flex justify-content-center">
                    <div class="col-12 d-flex justify-content-center login-logo_wrapper">
                        <a href="/"><img class="login-logo" src="../assets/logo.png" alt="Logo - Las Mieszkanias"></a>
                    </div>
                    <div class="col-10 col-md-10 col-lg-8 col-xl-6 justify-content-center login-panel">
                        <form method="POST" action="<?php echo e(route('login')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="mb-3">
                                <label for="exampleInputEmail1" class="form-label"><?php echo e(__('Adres e-mail')); ?></label>
                                <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>

                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="mb-3">
                                <label for="exampleInputPassword1" class="form-label"><?php echo e(__('Hasło')); ?></label>
                                <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="current-password">

                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="mb-3 form-check">
                                <input class="form-check-input" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                                <label class="form-check-label" for="remember">
                                    <?php echo e(__('Zapamiętaj mnie')); ?>

                                </label>
                            </div>

                            <button type="submit" class="btn-custom-solid color-white">
                                <?php echo e(__('Zaloguj')); ?>

                            </button>

                            <?php if(Route::has('password.request')): ?>
                            <a class="text-dark d-flex justify-content-end mt-2" href="<?php echo e(route('password.request')); ?>">
                                <?php echo e(__('Przypomnij hasło')); ?>

                            </a>
                            <?php endif; ?>
                            <hr>
                            <div class="mb-2">
                                Nie masz konta?
                            </div>
                            <a class="btn-custom-outline" href="<?php echo e(route('register')); ?>">
                                <?php echo e(__('Zarejestruj się!')); ?>

                            </a>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\lm\las-mieszkanias\resources\views/auth/login.blade.php ENDPATH**/ ?>