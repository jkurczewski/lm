

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row bg-cover_home d-flex justify-content-center ">
        <div class="col-12 col-md-12 header mb-4 mb-md-4">
           <h1>Twoje ulubione mieszkania</h1>
        </div>
        <div class="col-12 col-md-12">

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\lm\las-mieszkanias\resources\views/saved.blade.php ENDPATH**/ ?>