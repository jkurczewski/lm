

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row d-flex">
        <div class="col-8 mt-4 pt-4 mb-4">
            <h1>Twoje ulubione mieszkania</h1>
        </div>
        <div class="col-4 mt-4 pt-4 mb-4 d-flex justify-content-end align-items-center">
            <form action="<?php echo e(route('favs.destroyAll')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <button class="btn btn-danger text-white mb-3">Usuń wszystkie ulubione mieszkania</button>
            </form>
        </div>
        <div class="col-12 mt-4">
            <div class="row">
                <?php $__currentLoopData = $favs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-12 col-md-6 col-xl-4 mb-4">
                        <div class="card h-100">
                            <ul class="nav nav-pills" id="pills-tab" role="tablist">
                                <li class="nav-item" role="presentation">
                                    <button class="btn btn-custom-outline active"
                                            id="pills-home-tab-<?php echo e($rand.$loop->index); ?>" data-bs-toggle="pill"
                                            data-bs-target="#pills-home-<?php echo e($rand.$loop->index); ?>" type="button"
                                            role="tab" aria-controls="pills-home-<?php echo e($rand.$loop->index); ?>"
                                            aria-selected="true">Zdjęcie
                                    </button>
                                </li>
                                <li class="nav-item" role="presentation">
                                    <button class="btn btn-custom-outline border-button"
                                            id="pills-profile-tab-<?php echo e($rand.$loop->index); ?>" data-bs-toggle="pill"
                                            data-bs-target="#pills-profile-<?php echo e($rand.$loop->index); ?>" type="button"
                                            role="tab" aria-controls="pills-profile-<?php echo e($rand.$loop->index); ?>"
                                            aria-selected="false">Mapa
                                    </button>
                                </li>
                            </ul>

                            <div class="tab-content" id="pills-tabContent">
                                <div class="tab-pane fade show active" id="pills-home-<?php echo e($rand.$loop->index); ?>"
                                     role="tabpanel" aria-labelledby="pills-home-tab-<?php echo e($rand.$loop->index); ?>">
                                    <img src="<?php echo e($item['photo']); ?>" class="search-img" alt="">
                                </div>
                                <div class="tab-pane fade" id="pills-profile-<?php echo e($rand.$loop->index); ?>"
                                     role="tabpanel" aria-labelledby="pills-profile-tab-<?php echo e($rand.$loop->index); ?>">

                                    <iframe class="card-img-top" width="100%" height="350"
                                            src="https://maps.google.com/maps?q=<?php echo e($item['localization']); ?>&output=embed&z=12"></iframe>
                                </div>
                            </div>
                            <div class="card-body pb-0 pt-1">
                                <h5 class="col-12 mt-2 card-title fs-6"><?php echo e($item['localization']); ?></h5>
                                <h5 class="col-12 mt-2 mb-3 card-title fs-5 fw-bold price">
                                    <b><?php echo e($item['price']); ?></b></h5>
                            </div>

                            <div class="row px-4">
                                <hr class="mb-2"/>
                                <div class="col px-0 details-wrapper d-flex justify-content-center">
                                    <div class="icon-details me-2">
                                        <?php if (isset($component)) { $__componentOriginalcd9972c8156dfa6e5fd36675ca7bf5f21b506e2e = $component; } ?>
<?php $component = $__env->getContainer()->make(BladeUI\Icons\Components\Svg::class, []); ?>
<?php $component->withName('phosphor-house'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalcd9972c8156dfa6e5fd36675ca7bf5f21b506e2e)): ?>
<?php $component = $__componentOriginalcd9972c8156dfa6e5fd36675ca7bf5f21b506e2e; ?>
<?php unset($__componentOriginalcd9972c8156dfa6e5fd36675ca7bf5f21b506e2e); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                                    </div>
                                    <div class="mt-2 icon-text">
                                        Metraż<br><b class="fs-6"><?php echo e($item['space']); ?> </b>
                                    </div>
                                </div>
                                <div class="col ps-0 pe-2 details-wrapper d-flex justify-content-center">
                                    <div class="icon-details me-2">
                                        <?php if (isset($component)) { $__componentOriginalcd9972c8156dfa6e5fd36675ca7bf5f21b506e2e = $component; } ?>
<?php $component = $__env->getContainer()->make(BladeUI\Icons\Components\Svg::class, []); ?>
<?php $component->withName('bx-time-five'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalcd9972c8156dfa6e5fd36675ca7bf5f21b506e2e)): ?>
<?php $component = $__componentOriginalcd9972c8156dfa6e5fd36675ca7bf5f21b506e2e; ?>
<?php unset($__componentOriginalcd9972c8156dfa6e5fd36675ca7bf5f21b506e2e); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                                    </div>
                                    <div class="mt-2 icon-text">
                                        Dojazd<br><b class="fs-6"><?php echo e($item['time']); ?> min</b>
                                    </div>
                                </div>
                                <div class="col px-0 details-wrapper d-flex justify-content-center">
                                    <div class="icon-details me-2">
                                        <?php if (isset($component)) { $__componentOriginalcd9972c8156dfa6e5fd36675ca7bf5f21b506e2e = $component; } ?>
<?php $component = $__env->getContainer()->make(BladeUI\Icons\Components\Svg::class, []); ?>
<?php $component->withName('fluentui-conference-room-28'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalcd9972c8156dfa6e5fd36675ca7bf5f21b506e2e)): ?>
<?php $component = $__componentOriginalcd9972c8156dfa6e5fd36675ca7bf5f21b506e2e; ?>
<?php unset($__componentOriginalcd9972c8156dfa6e5fd36675ca7bf5f21b506e2e); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                                    </div>
                                    <div class="mt-2 icon-text">
                                        Pokoje<br><b class="fs-6"><?php echo e($item['rooms']); ?></b>
                                    </div>
                                </div>
                            </div>
                            <div class="row m-0 p-0 favs-action">
                                <a href="<?php echo e($item['url']); ?>" target="_blank"
                                   class="mt-4 btn btn-custom-solid btn-cards">Otwórz w nowej karcie</a>
                                <div>
                                    <form action="<?php echo e(route('favs.destroy', $item->id)); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <button href="#" class="mt-4 btn btn-heart_active deactive">
                                            <?php if (isset($component)) { $__componentOriginalcd9972c8156dfa6e5fd36675ca7bf5f21b506e2e = $component; } ?>
<?php $component = $__env->getContainer()->make(BladeUI\Icons\Components\Svg::class, []); ?>
<?php $component->withName('clarity-heart-broken-solid'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['alt' => 'Usuń ulubione mieszkanie']); ?>
<?php if (isset($__componentOriginalcd9972c8156dfa6e5fd36675ca7bf5f21b506e2e)): ?>
<?php $component = $__componentOriginalcd9972c8156dfa6e5fd36675ca7bf5f21b506e2e; ?>
<?php unset($__componentOriginalcd9972c8156dfa6e5fd36675ca7bf5f21b506e2e); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                                        </button>
                                    </form>
                                </div>
                            </div>

                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\lm\las-mieszkanias\resources\views/favs/saved.blade.php ENDPATH**/ ?>