<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row d-flex">
        <div class="col-12 col-md-12 header mt-4 mb-4">
           <h1>Twoje filtry wyszukiwania</h1>
        </div>
        <div class="col-12 mt-4">
            <div class="row">
                <?php $__currentLoopData = $filters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $filter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-12 col-md-6 col-lg-4 h-100">
                    <div class="card">
                        <div class="card-body pb-0 pt-1">
                            <h5 class="col-12 mt-2 card-title fs-4 mt-2"><b><?php echo e($filter->name); ?></b></h5>
                            <hr/>
                            <h5 class="col-12 mt-2 card-title fs-5">Lokalizacja: <b><?php echo e($filter->localization); ?></b></h5>
                            <h5 class="col-12 mt-2 card-title fs-5">Od <b><?php echo e($filter->min_budget); ?> zł/msc.</b> do <b><?php echo e($filter->max_budget); ?> zł/msc.</b></h5>
                            <h5 class="col-12 mt-2 card-title fs-5">Powierzchnia: <b><?php echo e($filter->min_space); ?> m2</b> - <b><?php echo e($filter->max_space); ?>m2</b></h5>
                            <h5 class="col-12 mt-2 card-title fs-5">Pokoje: <b>min. <?php echo e($filter->rooms); ?></b></h5>
                            <h5 class="col-12 mt-2 mb-3 card-title fs-5">W odległości od <b><?php echo e($filter->direction); ?></b> do <b><?php echo e($filter->direction_time); ?> min</b> </h5>
                            <hr/>
                            <div class="row">
                                <div class="col-8">
                                    <a href="#" class="btn btn-custom-solid h-20 ">Otwórz w nowej karcie</a>
                                </div>
                                <div class="col-4">
                                    <form action="<?php echo e(route('filters.destroy', $filter->id)); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <button class="btn btn-danger w-100 text-white mb-3">Usuń</button>
                                    </form>
                                </div>
                            </div>
                          </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\lm\las-mieszkanias\resources\views/filters/saved.blade.php ENDPATH**/ ?>