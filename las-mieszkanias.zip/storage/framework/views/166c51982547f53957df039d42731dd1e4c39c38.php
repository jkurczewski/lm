<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row d-flex">
            <div class="col-12 col-md-12 header mt-4 mb-4">
                <h1>Twoje filtry wyszukiwania</h1>
            </div>
            <div class="col-12 mt-4">
                <div class="row">
                    <?php $__currentLoopData = $filters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $filter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-12 col-md-6 col-lg-4 h-100">
                            <div class="card">
                                <div class="card-body pb-0 pt-1">
                                    <h5 class="col-12 mt-2 card-title fs-4 mt-2"><b><?php echo e($filter->name); ?></b></h5>
                                    <hr/>
                                    <h5 class="col-12 mt-2 card-title fs-5">Lokalizacja:
                                        <b><?php echo e($filter->localization); ?></b></h5>
                                    <h5 class="col-12 mt-2 card-title fs-5">Od <b><?php echo e($filter->min_budget); ?> zł/msc.</b>
                                        do <b><?php echo e($filter->max_budget); ?> zł/msc.</b></h5>
                                    <h5 class="col-12 mt-2 card-title fs-5">Powierzchnia: <b><?php echo e($filter->min_space); ?>

                                            m2</b> - <b><?php echo e($filter->max_space); ?>m2</b></h5>
                                    <h5 class="col-12 mt-2 card-title fs-5">Pokoje: <b>min. <?php echo e($filter->rooms); ?></b>
                                    </h5>
                                    <h5 class="col-12 mt-2 mb-3 card-title fs-5">W odległości od
                                        <b><?php echo e($filter->direction); ?></b> do <b><?php echo e($filter->direction_time); ?> min</b></h5>
                                    <hr/>
                                    <div class="row">
                                        <div class="col-8">
                                            <form action="<?php echo e(url('/')); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" value="<?php echo e($filter->localization); ?>"
                                                       name="localization">
                                                <input type="hidden" value="<?php echo e($filter->min_budget); ?>"
                                                       name="min_budget">
                                                <input type="hidden" value="<?php echo e($filter->max_budget); ?>"
                                                       name="max_budget">
                                                <input type="hidden" value="<?php echo e($filter->min_space); ?>" name="min_space">
                                                <input type="hidden" value="<?php echo e($filter->max_space); ?>" name="max_space">
                                                <input type="hidden" value="<?php echo e($filter->rooms); ?>" name="rooms">
                                                <input type="hidden" value="<?php echo e($filter->direction); ?>" name="direction">
                                                <input type="hidden" value="<?php echo e($filter->direction_time); ?>"
                                                       name="direction_time">
                                                <button class="btn btn-custom-solid h-20" data-bs-toggle="modal"
                                                        name="action" value="szukaj" data-bs-target="#waitingModal">
                                                    Wczytaj zapisany filtr
                                                </button>
                                            </form>
                                        </div>
                                        <div class="col-4">
                                            <form action="<?php echo e(route('filters.destroy', $filter->id)); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <button class="btn btn-danger w-100 text-white mb-3">Usuń</button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <div class="modal fade" id="waitingModal" data-bs-backdrop="static" tabindex="-1"
                 aria-labelledby="waitingModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content">
                        <div class="modal-body mt-4 mb-4">
                            
                            <div class="d-flex justify-content-center align-items-center flex-column">
                                <span id="flats" class="display-4"><b><?php echo e(Session::get('flats_count')); ?></b></span>
                                <span class="">Znalezionych mieszkań dla Ciebie!</span>
                                <span class="small text-secondary">Zrelaksuj się, proces poszukowania może potrwać kilka minut.</span>
                            </div>
                        </div>
                        <div class="slider">
                            <div class="line"></div>
                            <div class="subline inc"></div>
                            <div class="subline dec"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\lm\las-mieszkanias\resources\views/filters/saved.blade.php ENDPATH**/ ?>