<?php

return [
    'lang' => 'en',
    'timeout' => 1
];